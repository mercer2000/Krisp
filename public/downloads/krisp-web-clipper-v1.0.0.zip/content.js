// Krisp Web Clipper — Content Script
// Extracts structured content from the active page as blocks

(function () {
  "use strict";

  // Elements to strip from cloning
  const STRIP_SELECTORS = [
    "script",
    "style",
    "noscript",
    "iframe",
    "nav",
    "footer",
    "header",
    "[role='navigation']",
    "[role='banner']",
    "[role='contentinfo']",
    ".nav",
    ".navbar",
    ".footer",
    ".sidebar",
    ".ad",
    ".ads",
    ".advertisement",
    ".cookie-banner",
    ".cookie-consent",
    ".popup",
    ".modal",
    "#cookie-banner",
    "#gdpr",
  ];

  // Block-level elements that should become their own blocks
  const BLOCK_ELEMENTS = new Set([
    "P",
    "H1",
    "H2",
    "H3",
    "H4",
    "H5",
    "H6",
    "BLOCKQUOTE",
    "PRE",
    "UL",
    "OL",
    "LI",
    "HR",
    "DIV",
    "ARTICLE",
    "SECTION",
    "FIGURE",
  ]);

  // Max blocks to avoid huge payloads
  const MAX_BLOCKS = 80;

  // Listen for extraction requests from the popup
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message.type === "EXTRACT_CONTENT") {
      try {
        const result = extractContent();
        sendResponse(result);
      } catch (err) {
        sendResponse({
          success: false,
          error: err.message || "Extraction failed",
        });
      }
    }
    return true; // keep channel open for async response
  });

  function extractContent() {
    // Check for user selection first
    const selection = window.getSelection();
    const selectedText = selection ? selection.toString().trim() : "";

    if (selectedText && selectedText.length > 10) {
      // For selections, split into paragraph blocks
      const paragraphs = selectedText
        .split(/\n{2,}/)
        .map((p) => p.trim())
        .filter(Boolean);

      const blocks = paragraphs.map((text) => ({
        type: "paragraph",
        content: { text },
      }));

      return {
        success: true,
        title: document.title || "",
        url: window.location.href,
        domain: window.location.hostname,
        text: selectedText,
        blocks: blocks.slice(0, MAX_BLOCKS),
        isSelection: true,
      };
    }

    // Full page extraction — clone DOM and strip boilerplate
    const clone = document.cloneNode(true);

    for (const sel of STRIP_SELECTORS) {
      const elements = clone.querySelectorAll(sel);
      for (const el of elements) {
        el.remove();
      }
    }

    // Try to find the main content area
    const mainContent =
      clone.querySelector("article") ||
      clone.querySelector("main") ||
      clone.querySelector('[role="main"]') ||
      clone.querySelector(".post-content") ||
      clone.querySelector(".article-content") ||
      clone.querySelector(".entry-content") ||
      clone.querySelector("#content") ||
      clone.body;

    if (!mainContent) {
      return {
        success: false,
        error: "Unable to extract content from this page",
      };
    }

    // Extract structured blocks from the DOM
    const blocks = [];
    extractBlocks(mainContent, blocks);

    // Also get flat text for the brain thought embedding
    let text = mainContent.textContent || "";
    text = text
      .replace(/\t/g, " ")
      .replace(/ {2,}/g, " ")
      .replace(/\n{3,}/g, "\n\n")
      .trim();

    if (blocks.length === 0 && (!text || text.length < 20)) {
      return {
        success: false,
        error: "Unable to extract meaningful content from this page",
      };
    }

    // If structured extraction yielded nothing useful, fall back to text splitting
    if (blocks.length === 0 && text.length >= 20) {
      const paragraphs = text
        .split(/\n{2,}/)
        .map((p) => p.trim())
        .filter(Boolean);
      for (const p of paragraphs) {
        blocks.push({ type: "paragraph", content: { text: p } });
      }
    }

    return {
      success: true,
      title: document.title || "",
      url: window.location.href,
      domain: window.location.hostname,
      text: text,
      blocks: blocks.slice(0, MAX_BLOCKS),
      isSelection: false,
    };
  }

  /**
   * Walk the DOM tree and produce structured blocks.
   * Each block has { type, content } matching workspace block types.
   */
  function extractBlocks(root, blocks) {
    for (const node of root.childNodes) {
      if (blocks.length >= MAX_BLOCKS) return;

      if (node.nodeType === Node.TEXT_NODE) {
        const text = node.textContent.trim();
        if (text) {
          // Merge with previous paragraph if possible
          const last = blocks[blocks.length - 1];
          if (last && last.type === "paragraph") {
            last.content.text += " " + text;
          } else {
            blocks.push({ type: "paragraph", content: { text } });
          }
        }
        continue;
      }

      if (node.nodeType !== Node.ELEMENT_NODE) continue;

      const tag = node.tagName;

      // Skip invisible elements
      if (tag === "BR") continue;

      // Headings
      if (tag === "H1") {
        const text = getInnerText(node);
        if (text) blocks.push({ type: "heading_1", content: { text } });
        continue;
      }
      if (tag === "H2") {
        const text = getInnerText(node);
        if (text) blocks.push({ type: "heading_2", content: { text } });
        continue;
      }
      if (tag === "H3" || tag === "H4" || tag === "H5" || tag === "H6") {
        const text = getInnerText(node);
        if (text) blocks.push({ type: "heading_3", content: { text } });
        continue;
      }

      // Horizontal rule
      if (tag === "HR") {
        blocks.push({ type: "divider", content: {} });
        continue;
      }

      // Blockquote
      if (tag === "BLOCKQUOTE") {
        const text = getInnerText(node);
        if (text) blocks.push({ type: "quote", content: { text } });
        continue;
      }

      // Code blocks (pre > code)
      if (tag === "PRE") {
        const codeEl = node.querySelector("code");
        const text = (codeEl || node).textContent.trim();
        if (text) {
          // Try to detect language from class
          const langClass = (codeEl || node).className || "";
          const langMatch = langClass.match(
            /(?:language-|lang-)(\w+)/
          );
          const language = langMatch ? langMatch[1] : "";
          blocks.push({
            type: "code",
            content: { text, language },
          });
        }
        continue;
      }

      // Lists — extract each LI as a list item block
      if (tag === "UL") {
        extractListItems(node, "bulleted_list", blocks);
        continue;
      }
      if (tag === "OL") {
        extractListItems(node, "numbered_list", blocks);
        continue;
      }

      // Paragraphs
      if (tag === "P") {
        const text = getInnerText(node);
        if (text) blocks.push({ type: "paragraph", content: { text } });
        continue;
      }

      // Figure — look for image or caption
      if (tag === "FIGURE") {
        const img = node.querySelector("img");
        const caption = node.querySelector("figcaption");
        if (img && img.src) {
          blocks.push({
            type: "image",
            content: {
              url: img.src,
              caption: caption ? getInnerText(caption) : "",
            },
          });
        } else {
          // Fall through to extract inner content
          extractBlocks(node, blocks);
        }
        continue;
      }

      // Images (standalone)
      if (tag === "IMG") {
        const src = node.src || node.getAttribute("src");
        if (src) {
          blocks.push({
            type: "image",
            content: { url: src, caption: node.alt || "" },
          });
        }
        continue;
      }

      // For container elements (div, section, article), recurse
      if (
        tag === "DIV" ||
        tag === "SECTION" ||
        tag === "ARTICLE" ||
        tag === "MAIN" ||
        tag === "SPAN" ||
        tag === "A"
      ) {
        // Check if this div basically just wraps text (no block children)
        const hasBlockChildren = Array.from(node.children).some((child) =>
          BLOCK_ELEMENTS.has(child.tagName)
        );

        if (!hasBlockChildren) {
          // Treat as a paragraph
          const text = getInnerText(node);
          if (text) {
            blocks.push({ type: "paragraph", content: { text } });
          }
        } else {
          extractBlocks(node, blocks);
        }
        continue;
      }

      // Fallback: try to get text content
      const text = getInnerText(node);
      if (text) {
        blocks.push({ type: "paragraph", content: { text } });
      }
    }
  }

  /**
   * Extract list items from UL/OL into blocks.
   */
  function extractListItems(listNode, blockType, blocks) {
    for (const li of listNode.querySelectorAll(":scope > li")) {
      if (blocks.length >= MAX_BLOCKS) return;
      const text = getInnerText(li);
      if (text) {
        blocks.push({ type: blockType, content: { text } });
      }
    }
  }

  /**
   * Get clean inner text from an element, collapsing whitespace.
   */
  function getInnerText(el) {
    // Use innerText which respects visual rendering better than textContent
    let text = el.innerText || el.textContent || "";
    text = text.replace(/\t/g, " ").replace(/ {2,}/g, " ").trim();
    return text;
  }
})();
